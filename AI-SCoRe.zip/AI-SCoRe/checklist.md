\---

# SCoRe Checklist — Authoritative Reference

Source: https://jandul.github.io/NCA/score-checklist/
Book: Dul, J. (2026). Necessary Condition Analysis. Principles and Application. Chapman \& Hall/CRC Press.

## Critical instruction

The RECOMMENDATION is the primary evaluative standard for each item.
The QUESTION identifies where to look in the manuscript.
Always evaluate against the recommendation, not merely the surface question.

For each item, use the structured fields below to determine the verdict:

* **Pass criteria (Yes verdict requires ALL of)**: every listed condition must be met
* **Fail conditions (No verdict if ANY of)**: any one condition triggers a No
* **Unclear verdict when**: situations where insufficient information or genuine ambiguity warrants Unclear

**Important:** The Unclear verdict takes priority over Pass criteria. If an Unclear condition is met, assign Unclear regardless of whether Pass criteria are technically satisfied.

## N/A Rules (summary)

* Item 4: N/A if NO comparison is made with other types of causality (probabilistic sufficiency from regression, necessity or configurational sufficiency from QCA)
* Item 5: N/A if standalone NCA (no other method combined)
* Item 10: N/A if it is self-evident that the condition temporally precedes the outcome
* Item 12: N/A if NO diagram with arrows to represent the relationship between condition and outcome
* Item 15: N/A if NOT a large-n quantitative study or simulation (i.e., small-n)
* Item 16: N/A if NOT a small-n qualitative study (i.e., large-n or simulation)
* Item 18: N/A if data are NOT simulated
* Item 27: N/A if NO software is used (NOT a large-n quantitative or simulation; i.e. small-n qualitative study)
* Item 31: N/A if NOT a large-n quantitative study or simulation (i.e., small-n study)
* Item 34: N/A if NO bottleneck table or NO NN or NA in the bottleneck table
* Item 38: N/A if standalone NCA (no other method combined)

## Priority Counts (standard, all applicable)

Must-have: 22 | Should-have: 14 | Nice-to-have: 6

\---

## Section: Introduction/General

### Item 1 — Must-have

**Question:** Are the goals and contributions of applying NCA explicitly stated?

**Recommendation (primary evaluative standard):** State the primary and (possibly) secondary goals and contributions of the empirical NCA study. The study may primarily contribute to theory development by, for example, developing and testing new necessity hypotheses, developing an existing necessity claim further toward a formal necessity hypothesis and testing it with NCA, or replicating results of previously tested necessity hypotheses. Secondary goals could be methodological (e.g., introducing NCA to a new field/phenomenon), or practical (e.g., using results of NCA for practically meaningful recommendations/insights).

**Pass criteria (Yes verdict requires ALL of):**

* A primary goal is explicitly stated (theory-development contribution: testing new necessity hypotheses, developing existing claims toward formal hypotheses, or replicating tests)
* Secondary goals are stated if applicable (methodological introduction to a new field, or practical recommendations)

**Fail conditions (No verdict if ANY of):**

* Goals are not stated or are only implied
* Goals are framed only in probabilistic-sufficiency terms (e.g., "to predict the outcome") with no necessity-specific contribution
* The contribution is described only as "applying a new method" with no theory or practice rationale

**Unclear verdict when:**

* Goals are mentioned in passing but never collected or made explicit in one place
* The distinction between primary and secondary goals is so blurred that neither can be reliably identified

**Key concepts from the book:**

* A high-quality empirical NCA publication has two main parts: (1) reframing current understanding via necessity logic; (2) empirically testing one or more formal necessity hypotheses
* Contribution can follow the 5C/conversation structure: common ground → complication → concern → course of action → contribution
* Two contribution templates (Tables 10.1, 10.2): developing a new necessity hypothesis from scratch, or developing an existing necessity suggestion further
* Just formulating a necessity hypothesis without thought experiments, domain specification, or causal explanation does not qualify as a formal necessity hypothesis

**Common violations:**

* Stating only that "NCA is applied" without saying why
* Conflating the method's novelty with the study's contribution
* Listing many goals without prioritizing primary vs. secondary

**Book references:** [Chapter 7](https://jandul.github.io/nca-book/#hypothesisformulation), [Section 10.2](https://jandul.github.io/nca-book/#typesofncapublications), [Tables 10.1, 10.2](https://jandul.github.io/nca-book/#review)

\---

### Item 2 — Must-have

**Question:** When referring to necessity, are only words that correctly describe a necessity relationship used?

**Recommendation (primary evaluative standard):** When referring to necessity relationships, use appropriate terminology. In practice, this means using equivalents/derivatives of the statement that X is necessary for Y. Avoid ambiguous statements (X causes Y, X correlates with Y, X is associated with Y, X affects Y), or incorrect (sufficiency-based) statements such as X produces Y, X drives Y, X increases/decreases Y, etc.

**Pass criteria (Yes verdict requires ALL of):**

* All references to the necessity relationship use approved terminology (Table 7.1 enablers or constraints, or explicit "necessary for" phrasing)
* Discussion of necessity does not slip into ambiguous causal verbs ("causes," "affects," "is associated with," "correlates with," "leads to")
* Discussion of necessity does not slip into sufficiency-based verbs ("produces," "drives," "increases," "decreases")

**Fail conditions (No verdict if ANY of):**

* The hypothesized necessity relationship is described using sufficiency verbs at any point
* Probabilistic verbs (e.g., "X predicts Y," "X is associated with Y") are used to describe what NCA is testing

**Unclear verdict when:**

* Most usages are correct but isolated instances of ambiguous terminology appear in less central passages
* A term is borderline (e.g., "X is required for Y" is fine, but "X is involved in Y" is ambiguous)

**Key concepts from the book:**

* Table 7.1 lists approved enabler terms (necessary, needed, critical, crucial, essential, key, fundamental, pivotal, imperative, indispensable, prerequisite, requirement, conditio sine qua non, pre-condition, allows, enables, permits, "must-have," "Y requires X," etc.)
* Table 7.1 lists approved constraint terms (constrains, limits, blocks, bounds, restricts, stops, inhibits, hinders, prevents, impedes, disables, disallows, barrier, bottleneck, hurdle, "without X there cannot be Y")
* Forbidden ambiguous verbs: causes, correlates with, is associated with, affects
* Forbidden sufficiency verbs: produces, drives, increases, decreases

**Common violations:**

* Using "X predicts Y" or "X is associated with Y" in the necessity hypothesis statement
* Switching to probabilistic language in the discussion section after using necessity language in the methods
* Describing a necessary condition as one that "leads to" the outcome

**Book references:** [Table 7.1](https://jandul.github.io/nca-book/#sources), [Section 7.4.1.2](https://jandul.github.io/nca-book/#explicit)

\---

### Item 3 — Must-have

**Question:** Is it explained that NCA is an approach that combines both a specific causal logic (methodology) and the related data analysis technique (method)?

**Recommendation (primary evaluative standard):** Refer to NCA as a methodological approach that combines the theoretical perspective of necessity causality (rather than common probabilistic or configurational causality) with a corresponding data analysis method, ensuring theory-method fit. Emphasize that NCA entails more than just a data analysis or statistical method.

**Pass criteria (Yes verdict requires ALL of):**

* NCA is explicitly described as combining a causal logic (necessity causality) with a data analysis method
* It is explained that different causal perspectives require their own corresponding analysis method — and that NCA's necessity causal logic requires NCA as the analytical approach, not regression or QCA
* NCA is positioned as more than a statistical technique — as a methodological approach with a distinct causal perspective

**Fail conditions (No verdict if ANY of):**

* NCA is described only as a statistical method or data analysis technique
* The causal logic dimension of NCA is omitted entirely
* No explanation is given for why NCA (rather than another method) is appropriate for the necessity perspective

**Unclear verdict when:**

* The dual nature is acknowledged but the connection between causal perspective and analytical choice is not explained
* The correct method is used but the rationale for why necessity logic requires NCA specifically is missing

**Key concepts from the book:**

* NCA = causal logic (necessity: "if not X, then not Y") + data analysis method (ceiling line separating empty zone from feasible area)
* Theory-method fit: the hypothesis must be necessity-based for NCA to be the appropriate method
* NCA contrasts with regression/SEM (probabilistic sufficiency) and QCA (configurational/deterministic sufficiency)
* The key point: NCA is not a statistical add-on but a distinct causal perspective

**Common violations:**

* Describing NCA only as "a method for testing necessary conditions" without addressing the causal logic
* Treating NCA as a robustness check for regression results
* Failing to distinguish NCA's causal perspective from QCA's necessity analysis

**Book references:** [Chapter 1](https://jandul.github.io/nca-book/#introduction), [Chapter 2](https://jandul.github.io/nca-book/#causality), [Chapter 5](https://jandul.github.io/nca-book/#statistics); [Section 2.3](https://jandul.github.io/nca-book/#sufficiencycausality), [Section 2.4](https://jandul.github.io/nca-book/#necessitycausality)

\---

### Item 4 — Must-have

**Question:** Is a proper comparison made between NCA's causal perspective and conventional causal perspectives (e.g., probabilistic sufficiency, configurational sufficiency)?

**Recommendation (primary evaluative standard):** When comparing NCA's causal perspective with regression-based/statistical approaches, use the term "probabilistic sufficiency" for the latter, not just "sufficiency." The term sufficiency alone suggests determinism (as in QCA's configurational sufficiency logic). This recommendation is often violated in studies combining NCA with SEM. When NCA is compared with QCA's necessity analysis, use "necessity analysis of QCA" (not NCA) and explain the differences: QCA's necessity analysis only identifies necessity-in-kind, while NCA also identifies necessity-in-degree. Note: even standalone NCA articles should compare NCA's necessity causal perspective to conventional causal perspectives (probabilistic sufficiency) for illustration and explanation purposes.

**Pass criteria (Yes verdict requires ALL of):**

* NCA's causal perspective is compared to at least one conventional perspective (probabilistic sufficiency and/or configurational sufficiency)
* When regression/SEM is discussed, "probabilistic sufficiency" is used (not bare "sufficiency")
* When QCA's necessity analysis is discussed, it is distinguished from NCA (in-kind only vs. in-kind + in-degree)

**Fail conditions (No verdict if ANY of):**

* No comparison to any conventional causal perspective is made at all
* Regression/SEM is mentioned and bare "sufficiency" is used instead of "probabilistic sufficiency"
* QCA's necessity analysis is called "NCA" or treated as equivalent to NCA
* QCA's necessity analysis is mentioned but the difference from NCA (in-kind vs. in-kind + in-degree) is not explained

**Unclear verdict when:**

* The terminology is mostly correct but slips at isolated points
* A comparison is made but the depth of explanation is insufficient to confidently assess whether the distinction was understood

**Key concepts from the book:**

* Three perspectives on sufficiency causality (Table 2.1): deterministic (if X, then always Y — QCA, SCC, NESS), probabilistic (if X, then probably Y — LR, MLR, SEM), typicality (if X, then typically Y)
* Three perspectives on necessity (Table 2.2): deterministic (if not X, then always not Y — NCA), probabilistic (PN), typicality (if not X, then typically not Y — NCA)
* QCA's necessity analysis only identifies necessity-in-kind; NCA also identifies necessity-in-degree
* QCA's necessity analysis often misses necessary conditions entirely (Torres \& Godinho, 2022)

**Common violations:**

* Using "sufficiency" without the "probabilistic" qualifier when discussing regression
* Treating SEM's causal logic as deterministic
* Conflating QCA's necessity analysis with NCA

**Book references:** [Section 2.3](https://jandul.github.io/nca-book/#sufficiencycausality), [Section 2.4](https://jandul.github.io/nca-book/#necessitycausality), [Table 2.1](https://jandul.github.io/nca-book/#sufficiencycausality), [Table 2.2](https://jandul.github.io/nca-book/#necessitycausality)

\---

### Item 5 — Must-have

**Question:** In multimethod studies, is NCA described and used as an approach with a specific perspective on causality and data analysis, and not merely as a robustness check or an add-on to other methods (and vice versa)?

**Recommendation (primary evaluative standard):** In multimethod studies, use and refer to NCA as an approach with a specific perspective on causality and data analysis, and do not incorrectly refer to it as a robustness check or add-on to other methods (and vice versa). This recommendation is often violated in studies combining NCA with SEM.

**Pass criteria (Yes verdict requires ALL of):**

* NCA is presented as having a distinct causal perspective complementary to the other method, not a verification of it
* NCA results are interpreted in their own right (necessity-in-kind, necessity-in-degree, bottleneck), not just as confirmation of regression/SEM/QCA findings
* The other method is also not reduced to a robustness check for NCA

**Fail conditions (No verdict if ANY of):**

* NCA is explicitly or implicitly framed as a robustness check for SEM/regression/QCA
* The complementary nature of the two causal perspectives is not addressed
* NCA findings are dismissed when they do not align with the other method's findings

**Unclear verdict when:**

* The framing is ambiguous about which method serves what role
* The multimethod combination is mentioned but the rationale for using both is not articulated

**Key concepts from the book:**

* Causal-pluralism multimethod studies use multiple methods with distinct causal perspectives, not the same perspective
* Method-triangulation uses methods with the same causal perspective for robustness — NCA + regression is not triangulation because the perspectives differ
* NCA answers "what is necessary?" (bottleneck logic); regression/SEM answers "what contributes on average?" (probabilistic sufficiency); QCA answers "what combinations are sufficient?" (configurational sufficiency)

**Common violations:**

* "NCA was conducted as a robustness check to confirm the SEM results"
* Reporting NCA only when its conclusions match regression conclusions
* Treating mismatches between NCA and regression as a problem rather than informative

**N/A condition:** Standalone NCA studies (no other method combined).

**Book references:** [Section 2.7](https://jandul.github.io/nca-book/#underdetermination), [Section 11.4](https://jandul.github.io/nca-book/#ncasem), [Section 11.5](https://jandul.github.io/nca-book/#ncaqca)

\---

### Item 6 — Nice-to-have

**Question:** If the necessity analysis is a prominent part of the publication, do the title and abstract reflect this necessity perspective/NCA?

**Recommendation (primary evaluative standard):** If important parts of the publication and/or its conclusions are based on necessity logic and NCA, ensure that this is reflected in the title and abstract by using words that reflect necessity logic or NCA.

**Pass criteria (Yes verdict requires ALL of):**

* The title contains necessity-related terms (Table 7.1) OR explicit mention of "NCA" / "necessary condition analysis"
* The abstract uses necessity-related terminology when describing the analysis or conclusions

**Fail conditions (No verdict if ANY of):**

* Title and abstract describe the analysis only in probabilistic or generic terms despite prominent necessity content
* Necessity findings are buried under sufficiency-framed framing in the abstract

**Unclear verdict when:**

* Title has necessity terms but abstract does not, or vice versa
* The necessity perspective is a minor part of the paper (in which case absence may be appropriate)

**Key concepts from the book:**

* Appropriate terms include Table 7.1 entries plus explicit "necessary condition analysis" / "NCA"
* The purpose is discoverability: readers and databases should be able to identify the necessity perspective

**Common violations:**

* Title uses neutral framing ("Determinants of X") even though NCA is central
* Abstract uses "predicts" or "is associated with" throughout

**Book references:** [Table 7.1](https://jandul.github.io/nca-book/#sources)

\---

## Section: Theory/Hypotheses

### Item 7 — Must-have

**Question:** Is the hypothesized necessity relationship explicitly formulated as: X is necessary for Y, or similar?

**Recommendation (primary evaluative standard):** Formulate the necessity relationship explicitly as a necessary condition hypothesis: "X is necessary for Y." For a deductive study, this is done before data analysis; for an explorative study, this is done after data analysis when indications for a necessity relationship are found.

**Pass criteria (Yes verdict requires ALL of):**

* An explicit hypothesis statement of the form "X is necessary for Y" (or an approved equivalent from Table 7.1) appears in the paper
* For deductive studies: the hypothesis precedes the data analysis section
* For exploratory studies: the post-hoc nature of the hypothesis formulation is clearly stated

**Fail conditions (No verdict if ANY of):**

* No explicit hypothesis statement appears anywhere
* The hypothesis is implied but never stated using necessity language
* Exploratory hypothesis formulation is not labeled as such

**Unclear verdict when:**

* A hypothesis-like statement appears but in non-standard wording that may or may not constitute a formal necessity hypothesis

**Key concepts from the book:**

* A formal necessity hypothesis has five characteristics: theory-grounded, testable, non-trivial, plausible, complete
* Deductive: hypothesis precedes data collection
* Exploratory: hypothesis formulated post-hoc when necessity patterns appear in the data; must be clearly labeled

**Common violations:**

* Treating "X is associated with Y" as a necessity hypothesis
* Formulating hypotheses only in the results section without acknowledging the post-hoc nature
* Listing variables as "potential necessary conditions" without formal hypothesis statements

**Book references:** [Section 7.5](https://jandul.github.io/nca-book/#developingformaltheory), [Section 7.5.1](https://jandul.github.io/nca-book/#preliminarytheory)

\---

### Item 8 — Must-have

**Question:** Are the four elements of a necessity theory precisely defined: concepts X and Y, direction of the hypothesis, focal unit, theoretical domain?

**Recommendation (primary evaluative standard):** To obtain a formal necessity hypothesis that is ready for testing, precisely define all four elements: (1) Define concepts X and Y according to their meaning in the hypothesis. (2) Specify the hypothesis direction — which corner of the XY-plot is expected to be empty, particularly if not the default upper-left corner. (3) Specify the focal unit of which X and Y are characteristics. (4) Define the theoretical domain where the hypothesis is claimed to hold, given its boundary conditions. Note: the theoretical domain is usually larger than the population from which cases are selected.

**Pass criteria (Yes verdict requires ALL of):**

* Concepts X and Y are precisely defined (not just named)
* The hypothesis direction is explicitly stated (which corner is expected to be empty: +nc+, -nc+, +nc-, or -nc-)
* The focal unit is identified (singular noun: person, team, country, etc.)
* The theoretical domain is defined (temporal, geographic, demographic, or conceptual boundaries)

**Fail conditions (No verdict if ANY of):**

* One or more of the four elements is missing or implicit
* The direction is not stated, including when the expected corner is the default upper-left and this is not explicitly confirmed
* The theoretical domain is conflated with the sampled population without distinction

**Unclear verdict when:**

* The elements are scattered across the paper and not collected as a formal theory specification

**Key concepts from the book:**

* The four elements together constitute "theory-grounding" of the hypothesis
* Direction: +nc+ (high-high), -nc+ (low-high), +nc- (high-low), -nc- (low-low); default is +nc+
* Focal unit: a singular noun (e.g., "person," "parent-child pair"); cases sampled must be instances of this unit
* Theoretical domain ≠ population: the domain is broader; the population is a slice of it from which cases are drawn

**Common violations:**

* Defining concepts but never stating the direction
* Naming the focal unit indirectly (through the sample) rather than as a theoretical category
* Treating "all adults" or "all firms" as the theoretical domain without specifying boundary conditions

**Book references:** [Section 3.2](https://jandul.github.io/nca-book/#definitionnecessitytheory), [Section 3.5](https://jandul.github.io/nca-book/#direction), [Chapter 7](https://jandul.github.io/nca-book/#hypothesisformulation), [Section 7.5.1](https://jandul.github.io/nca-book/#preliminarytheory), [Figures 3.6–3.8](https://jandul.github.io/nca-book/#direction)

\---

### Item 9 — Must-have

**Question:** Is a causal explanation provided WHY X is necessary for Y using necessity causal logic, addressing three questions: Why does X enable Y? Why does the absence of X lead to the absence of Y? Why is the absence of X not compensable?

**Recommendation (primary evaluative standard):** Explain why X is necessary for Y using a causal explanation (narrative) by answering three questions: (1) Why does X enable Y (X is an enabler — how the presence of X allows Y to occur); (2) Why does the absence of X lead to the absence of Y (X is a constraint — how the absence of X disrupts the causal mechanism); (3) Why is the absence of X not compensable (no substitution for X — no alternative path to Y exists without X). Making the narrative complete is a creative process, supported by literature and practitioner experience.

**Pass criteria (Yes verdict requires ALL of):**

* An explicit enabler explanation: a causal mechanism showing how the presence of X allows or contributes to Y occurring
* An explicit constraint explanation: how the absence of X disrupts the causal mechanism, preventing Y
* An explicit non-compensability explanation: an independent argument for why no alternative path or substitute factor can produce Y without X
* The three explanations are provided for each tested condition X, not just for the framework as a whole

**Fail conditions (No verdict if ANY of):**

* One or more of the three questions is unaddressed
* Non-compensability is asserted as a conclusion of necessity rather than independently argued (e.g., "X is non-compensable because it is necessary")
* The argument applies generically to the framework but does not address each specific condition tested
* Probabilistic/sufficiency reasoning is used to justify necessity (e.g., "X strongly contributes to Y, therefore X is necessary")

**Unclear verdict when:**

* The three components are present but not clearly mapped to the recommendation's three-question structure, making it ambiguous whether each was genuinely addressed

**Key concepts from the book:**

* The three questions map onto Figure 7.5: enabler (upper-right quadrant), constraint (lower-left), no substitute (upper-left)
* Step 3 of the formal hypothesis development process (after preliminary theory and thought experiments)
* The non-compensability question is the most distinctive element of necessity theory — most failures cluster here
* If an alternative substitution path is discovered during the explanation, the analyst must return to Step 2 (thought experiments), not paper over it
* Q13 (temporal aspects) is also part of Section 7.5.3 but is evaluated under Item 10

**Common violations:**

* Treating non-compensability as a definition rather than something requiring causal argument
* Citing CoR theory, vulnerability-stress paradigm, or similar frameworks as if they automatically establish non-compensability — frameworks identify factors as "important" but do not by themselves establish that one factor cannot substitute for another
* Providing a single generic argument and applying it to multiple distinct conditions without case-by-case justification

**Book references:** [Chapter 7](https://jandul.github.io/nca-book/#hypothesisformulation), [Section 7.5.3](https://jandul.github.io/nca-book/#causalexplanation), [Figure 7.5](https://jandul.github.io/nca-book/#causalexplanation), [Figure 7.6](https://jandul.github.io/nca-book/#causalexplanation)

\---

### Item 10 — Must-have

**Question:** Are temporal aspects considered including specification of the temporal order of X and Y if this is not obvious?

**Recommendation (primary evaluative standard):** If not self-evident, include a plausible explanation of the temporal order (first X then Y). If the data support X is necessary for Y, explain why the alternative reverse explanation — that Y is sufficient for X (or: absence of Y is necessary for absence of X) — is also consistent with the expected empty space but is not plausible. Also consider: whether X is necessary for the onset or continuation of Y, and whether the hypothesis holds in all time periods.

**Pass criteria (Yes verdict requires ALL of):**

* Temporal order (X before Y) is established — either by study design (e.g., time-lagged longitudinal) or by explicit theoretical argument
* If temporal order is not self-evident, the reverse causal alternative is addressed and ruled out
* Onset vs. continuation distinction is considered when relevant (e.g., is X needed only initially, or continuously?)
* Time-period dependency is addressed when relevant (does the necessity hold across all time periods?)

**Fail conditions (No verdict if ANY of):**

* Temporal order is asserted but not argued, despite not being self-evident in a cross-sectional design
* Reverse causality is not addressed in cross-sectional observational studies
* The onset/continuation and time-period questions are not considered when they are clearly relevant

**Unclear verdict when:**

* Temporal order is established by design but reverse-causality theoretical alternatives are not explicitly considered
* The onset/continuation question is implicit but not stated

**Key concepts from the book:**

* An empty upper-left corner in a high-high hypothesis (X→Y) is observationally equivalent to a low-low necessity in the reverse direction (Y→X) — Figure 5.9
* Three temporal aspects from Q13 (Figure 7.6): (1) temporal order; (2) onset vs. continuation (e.g., a match is necessary for onset of fire but not continuation); (3) time-period dependency
* Cross-sectional designs are especially vulnerable to reverse-causality claims and require explicit theoretical ruling-out
* Longitudinal/time-lagged designs partially address temporal order but do not fully rule out theoretical reverse-causality alternatives

**Common violations:**

* Cross-sectional study claiming necessity without addressing reverse causality
* Assuming temporal order is "obvious" when in fact a reverse mechanism is plausible
* Skipping the onset/continuation distinction in clearly time-dependent phenomena

**Book references:** [Section 2.5](https://jandul.github.io/nca-book/#causalversusconditionallogic), [Section 5.7](https://jandul.github.io/nca-book/#reversecausality), [Chapter 7](https://jandul.github.io/nca-book/#hypothesisformulation), [Section 7.5.3](https://jandul.github.io/nca-book/#causalexplanation), [Figure 7.6](https://jandul.github.io/nca-book/#causalexplanation), [Figure 5.9](https://jandul.github.io/nca-book/#reversecausality)

\---

### Item 11 — Should-have

**Question:** Is the existing literature about the relationship between X and Y re-considered from a necessity causal perspective?

**Recommendation (primary evaluative standard):** Review existing literature (that commonly describes probabilistic relationships between X and Y) to find hints for necessity causality. Avoid just describing, summarizing, or referring to probabilistic findings/ideas. Where possible, include quotes in the literature that hint to necessity logic. Avoid using sufficiency/probabilistic causal logic for making a justification for necessity causal logic. Note that only describing, summarizing, or quoting prior work (often based on probabilistic sufficiency logic) does not constitute a valid theoretical justification of a necessity hypothesis.

**Pass criteria (Yes verdict requires ALL of):**

* Existing literature is reviewed and actively reinterpreted from a necessity perspective (not just described)
* Hints for necessity in prior probabilistic work are identified — e.g., quotes using Table 7.1 terminology, or causal narratives whose "loss of function" implications point to necessity
* Probabilistic/sufficiency findings are not used as justification for necessity claims

**Fail conditions (No verdict if ANY of):**

* The literature review only describes probabilistic findings without reinterpreting them
* Necessity is justified by appealing to the strength of probabilistic effects

**Unclear verdict when:**

* The review covers prior literature thoroughly but the reinterpretation is implicit rather than explicit
* Some hints are identified but others are clearly missed

**Key concepts from the book:**

* Four knowledge sources for necessity hints (Section 7.4.1):

  * Necessity theories (prior explicit necessity claims)
  * Necessity statements (using Table 7.1 terms, even if probabilistic methods were used)
  * Causal models (existing probabilistic models can be re-examined for which factors might be necessary)
  * Causal narratives (existing causal stories evaluated for "loss of function" logic)
* Bokrantz \& Dul (2023) in supply chain management identified 157 necessity statements in major journals that had not been properly tested as necessity

**Common violations:**

* Standard literature review style: describing prior probabilistic findings without re-examining them through necessity lens
* Citing meta-analyses of average effects as evidence for necessity
* Failing to extract quotes from prior work that hint at necessity logic

**Book references:** [Section 7.4.1](https://jandul.github.io/nca-book/#sources), [Table 7.1](https://jandul.github.io/nca-book/#sources), [Sections 7.4.1.1–7.4.1.4](https://jandul.github.io/nca-book/#explicit)

\---

### Item 12 — Nice-to-have

**Question:** If applicable, is an "nc" symbol added near the arrow in a diagram that represents a necessity relationship?

**Recommendation (primary evaluative standard):** In a diagram representing an (expected) necessity relationship between two variables using an arrow, add a relevant symbol (+nc+, -nc+, -nc-, or +nc-) near the arrow to show the direction of necessity.

**Pass criteria (Yes verdict requires ALL of):**

* A conceptual diagram exists showing X→Y relationships
* The diagram includes nc-symbols (+nc+, -nc+, +nc-, or -nc-) on the relevant arrows
* The symbol correctly matches the hypothesized direction

**Fail conditions (No verdict if ANY of):**

* A conceptual diagram exists but uses only +/- symbols (sufficiency convention) for what is described as a necessity relationship
* No nc-symbols appear despite necessity relationships being diagrammed

**Unclear verdict when:**

* The diagram uses unconventional notation that may or may not be intended as nc-equivalent

**N/A condition:** The paper contains no conceptual diagram.

**Key concepts from the book:**

* Four directions and symbols (Figure 3.6):

  * +nc+ (high-high): presence of X necessary for presence of Y
  * \-nc+ (low-high): absence of X necessary for presence of Y
  * +nc- (high-low): presence of X necessary for absence of Y
  * \-nc- (low-low): absence of X necessary for absence of Y
* Default is +nc+ if not stated
* The symbol distinguishes necessity arrows from sufficiency arrows (+/- convention)

**Common violations:**

* Using only "+" or "→" arrows for necessity relationships in conceptual models
* Mixing necessity and sufficiency relationships in the same diagram without distinguishing them

**Book references:** [Section 3.5](https://jandul.github.io/nca-book/#direction), [Figure 3.6](https://jandul.github.io/nca-book/#direction)

\---

### Item 13 — Nice-to-have

**Question:** Is it specified if rare exceptions are allowed (typicality perspective)?

**Recommendation (primary evaluative standard):** Explain whether the necessity theory allows for rare exceptions (typicality perspective), or whether any exception leads to a rejection of the theory (deterministic perspective). The typicality perspective is not a solution for poor measurement and should not be used in a probabilistic manner (e.g., ignoring a certain percentage of cases above the ceiling).

**Pass criteria (Yes verdict requires ALL of):**

* The paper explicitly states whether a deterministic or typicality perspective is adopted
* If typicality is adopted, exceptions are characterized as rare, isolated, far from the ceiling, and behaving differently for unknown reasons (not as a percentage tolerance)
* If a mechanistic outlier rule is applied (e.g., "remove if d changes ≥20%"), a theoretical justification accompanies it
* When typicality is adopted and outliers removed as exceptions, a robustness check with and without the exception is conducted

**Fail conditions (No verdict if ANY of):**

* The perspective cannot be stated or inferred from the analysis approach
* Typicality is used as cover for accepting a percentage of violations without theoretical grounding
* A mechanistic outlier rule is applied without theoretical justification
* Many unexplained points above the ceiling are tolerated under the "typicality" label rather than triggering rejection

**Unclear verdict when:**

* The perspective is implicit in the analysis but not explicitly stated, and cannot be reliably inferred (e.g., some outliers were removed but the basis — error correction vs. typicality — is unclear)

**Key concepts from the book:**

* Typicality necessity: "if not X, then typically not Y" — allows rare exceptions in terms of cardinality, not probability
* Exceptions must be: rare, not errors, isolated, far from the ceiling (in the low-purity zone), behaving differently for unknown reasons
* Cases in the medium-purity zone (close to ceiling) are noise, not exceptions
* Many unexplained points above the ceiling → reject necessity, do not adopt typicality
* Mechanistic outlier rules are generally discouraged; if used, a theoretical justification is required

**Common violations:**

* Removing outliers based purely on percentage thresholds without theoretical justification
* Using typicality language to justify what is effectively probabilistic tolerance
* Not distinguishing noise (medium-purity zone) from exceptions (low-purity zone)

**Book references:** [Section 2.4.3](https://jandul.github.io/nca-book/#typicalitynecessity), [Section 4.5.4](https://jandul.github.io/nca-book/#purity), [Section 9.8.3](https://jandul.github.io/nca-book/#outlierdecisionmaking), [Figure 9.4](https://jandul.github.io/nca-book/#outlierdecisionmaking)

\---

## Section: Methods — Data

### Item 14 — Must-have

**Question:** Is the study design (observational study, longitudinal study, case study, experimental study) adequate?

**Recommendation (primary evaluative standard):** Possible study designs for NCA include the large-n observational study (both X and Y are observed), the longitudinal study (X and Y data from different time points), the small-n case study (X and Y are observed), and the experiment (X is manipulated and Y is observed). The general principles for good study design apply. For case selection and experiments, there is an NCA-specific approach.

**Pass criteria (Yes verdict requires ALL of):**

* The study design is one of the four supported types (observational, longitudinal, case study, experiment)
* The design is appropriate for the necessity hypothesis being tested
* General principles of good study design are followed
* For experiments and case studies, the NCA-specific approach (purposive selection, manipulation logic) is applied

**Fail conditions (No verdict if ANY of):**

* The design is not appropriate for testing necessity (e.g., aggregated data that loses individual variation)
* The design does not match the focal unit specified in the theory
* Standard design quality criteria are not met

**Unclear verdict when:**

* The design is appropriate but its rationale is not explained
* The design borders multiple types (e.g., a cross-sectional sample drawn from a longitudinal study)

**Key concepts from the book:**

* Observational (cross-sectional) is the most common NCA design; advantageous because it does not suffer from omitted variable bias
* Longitudinal designs handle time trends and can reduce reverse causality via time-lagging
* Case studies use purposive selection (Section 8.3.2)
* Experiments require manipulation of X and observation of Y; NCA-specific principles apply

**Common violations:**

* Cross-sectional designs claiming temporal causation
* Aggregated data (e.g., country averages) used to test individual-level necessity
* Mismatched focal units between theory and design

**Book references:** [Section 8.2](https://jandul.github.io/nca-book/#researchdesign), [Sections 8.2.1–8.2.4](https://jandul.github.io/nca-book/#observationalstudy)

\---

### Item 15 — Should-have

**Question:** For large-n quantitative studies: are adequate sampling approaches used and is a pre-study power analysis reported?

**Recommendation (primary evaluative standard):** For large-n quantitative studies the preferred sampling approach from the theoretical domain is random sampling with good coverage of the population of interest. The general principles for good sampling apply. Report if an NCA-specific pre-study power analysis was done to estimate the required sample size for finding necessity if it exists. Note that doing a post-hoc power analysis makes no sense for the present study, but could inform future studies.

**Pass criteria (Yes verdict requires ALL of):**

* The sampling approach is described
* If convenience sampling was used, limitations regarding representativeness are acknowledged
* The paper addresses whether a pre-study power analysis was done — either by reporting one, explaining why one was not feasible, or providing a clear rationale demonstrating adequate power (e.g., "given N = X, the study had sufficient power for d ≥ Y")

**Fail conditions (No verdict if ANY of):**

* Sampling approach is not described
* The power question is entirely unaddressed
* A post-hoc power analysis is presented as justification for the present study's adequacy

**Unclear verdict when:**

* Sampling is described but the power discussion is implicit
* The sample's representativeness is questionable but limitations are not acknowledged

**Key concepts from the book:**

* Random sampling preferred; convenience sampling acceptable if limitations acknowledged
* Minimum sample sizes for 80% power (for d=0.10): \~60 with uniform distribution, \~300 with truncated normal distribution
* For d=0.50 with 80% power: \~30 cases
* Post-hoc power analysis is explicitly invalid (Section 5.6)
* NCA power analysis uses the nca\_power function
* A brief acknowledgment ("given N=3,077, power was clearly adequate for detecting even small effects of d≥0.05") satisfies this item

**Common violations:**

* Convenience sampling without acknowledging implications for representativeness
* Reporting only descriptive sample size without power consideration
* Conducting and reporting post-hoc power analyses

**N/A condition:** Not a large-n quantitative study (i.e., small-n or simulation).

**Book references:** [Section 5.6](https://jandul.github.io/nca-book/#statisticspower), [Section 8.3.1](https://jandul.github.io/nca-book/#largensampling)

\---

### Item 16 — Should-have

**Question:** For small-n qualitative studies: are adequate NCA-specific approaches used for purposive case selection?

**Recommendation (primary evaluative standard):** For small-n qualitative NCA studies, aim to use purposive selection of cases from the theoretical domain, with cases being selected based on the presence of Y or absence of X. Always clearly state how cases were selected. Reflect on, and report the potential limitations when cases were not selected purposively based on the absence of X or presence of Y.

**Pass criteria (Yes verdict requires ALL of):**

* The case selection method is clearly stated
* Either: cases are selected purposively based on Y=1 (outcome present) or X=0 (condition absent); OR: a non-purposive selection method is used with explicit, substantive reflection on the limitations this creates for testing necessity

**Fail conditions (No verdict if ANY of):**

* Selection method is not stated
* Non-purposive selection is used with no acknowledgment of its NCA-specific limitations

**Unclear verdict when:**

* Selection is described but it is ambiguous whether it was purposive or convenience
* Reflection on limitations is present but superficial

**Key concepts from the book:**

* Purposive selection: choose cases where Y=1 (outcome present) or X=0 (condition absent)
* If X is present in all Y=1 cases → necessity supported
* If Y is present in any X=0 case → necessity rejected
* Replication logic: confidence increases with more non-falsifying cases
* Single-case studies are possible but require strong replication

**Common violations:**

* Convenience-selected small samples
* Selecting cases that vary on X without considering Y
* Skipping reflection on selection limitations

**N/A condition:** Not a small-n qualitative study (i.e., large-n or simulation).

**Book references:** [Section 8.2.3](https://jandul.github.io/nca-book/#casestudy), [Section 8.3.2](https://jandul.github.io/nca-book/#smallncaseselection)

\---

### Item 17 — Must-have

**Question:** Are adequate measurement approaches used for getting scores of X and Y, and are these measures practically interpretable?

**Recommendation (primary evaluative standard):** Ensure a proper measurement approach with valid, reliable, and meaningful data (scores of X and Y). Data are input to NCA, not part of NCA. General principles for good data collection apply. For interpretation of results, it is important that the scores have a practical meaning in terms of the levels of X and Y. Data are stored in a dataset. The dataset may consist of archival data.

**Pass criteria (Yes verdict requires ALL of):**

* Measures are valid (measuring the intended concept)
* Measures are reliable (consistency reported when applicable)
* Scores of X and Y have practical meaning — the levels are interpretable in substantive terms
* If archival data are used, sources are acknowledged and any adaptations are justified

**Fail conditions (No verdict if ANY of):**

* Measures lack documented validity or reliability for the concepts
* Scale levels are arbitrary or undefined, making scores uninterpretable in substantive terms
* Archival data sources are unacknowledged or unjustified

**Unclear verdict when:**

* Reliability information is missing but validity is established
* Scale construction is partially documented

**Key concepts from the book:**

* NCA accepts any meaningful, valid, reliable scores: quantitative (continuous, discrete, dichotomous), qualitative, or set membership
* Practical interpretability is critical for necessity-in-degree: the bottleneck table states "level X is necessary for level Y" — if levels have no meaning, the table is uninterpretable
* Archival data acceptable if origins evaluated, adaptations justified, prior studies referenced

**Common violations:**

* Aggregated indices with unclear scale anchors
* Standardized scores presented without back-conversion to interpretable levels
* Archival data sources not documented

**Book references:** [Section 8.4](https://jandul.github.io/nca-book/#measurement), [Section 8.5.1](https://jandul.github.io/nca-book/#archivaldata)

\---

### Item 18 — Must-have

**Question:** For simulation studies: are simulated data sampled from bounded distributions of X and Y?

**Recommendation (primary evaluative standard):** For data generated by simulation, ensure that the variables X and Y are bounded (have minimum and maximum values). Simulated data drawn from, for example, a normal distribution would not be eligible whereas data from a uniform or truncated normal distribution would be appropriate.

**Pass criteria (Yes verdict requires ALL of):**

* Simulation data are drawn from bounded distributions (uniform, truncated normal, or similar)
* The bounds are explicitly stated
* The bounded nature of the distribution is justified

**Fail conditions (No verdict if ANY of):**

* Data drawn from unbounded distributions (e.g., normal without truncation)
* Bounds are not stated

**Unclear verdict when:**

* The distribution is mentioned but its bounded/unbounded status is not addressed

**Key concepts from the book:**

* NCA assumes X and Y are bounded variables — required for meaningful scope and effect size
* Normal distribution (unbounded) makes the scope potentially infinite, leading to effect size of 0
* Uniform or truncated normal distributions provide a well-defined scope

**Common violations:**

* Using a normal distribution for simulation without truncation
* Not stating bounds explicitly

**N/A condition:** Data are not simulated.

**Book references:** [Section 4.3](https://jandul.github.io/nca-book/#formalexpression), [Section 5.4](https://jandul.github.io/nca-book/#statisticalmodeling)

\---

### Item 19 — Must-have

**Question:** Are only data transformations that align with NCA employed?

**Recommendation (primary evaluative standard):** Explain whether and how the data were transformed, and whether the transformation aligns with NCA. Affine transformations (including linear transformation) produce valid results. NCA does not require data transformation and non-transformed data are often more meaningful (e.g., levels of a Likert scale) than transformed data. This particularly applies to necessity-in-degree. Refrain from conducting non-linear data transformations (e.g., log-transformation, logistic transformation) unless the transformed data represent X and Y as defined in the necessity hypothesis (e.g., log-transformed GDP). This may be violated in NCA+QCA studies when logistic transformation is applied for calibration.

**Pass criteria (Yes verdict requires ALL of):**

* The paper states whether data were transformed
* If transformed, the transformation is affine (linear, z-score, min-max) OR the non-linear transformation is justified by representing the concept as defined in the hypothesis (e.g., log GDP for "economic prosperity")
* If not transformed, this is implicit or stated and original scores are used

**Fail conditions (No verdict if ANY of):**

* Non-linear transformations applied without justification (e.g., log just for normality)
* Logistic/S-curve calibration applied for NCA portion of NCA+QCA without justification
* Transformation status is unclear and the variables show signs of transformation

**Unclear verdict when:**

* No statement on transformation is made but the variables appear potentially transformed
* A construct is derived from indicators with unclear aggregation method

**Key concepts from the book:**

* Affine transformations (linear, z-score, min-max) do not affect NCA effect size or p-value
* Non-linear transformations (log, logistic) DO affect ceiling line, effect size, and p-value
* Exception: when the non-linear transformation IS the valid representation of the concept (e.g., log GDP)
* In NCA+QCA: calibration via logistic transformation is needed for QCA but should be avoided or justified for NCA

**Common violations:**

* Log-transforming skewed variables for normality (not needed in NCA)
* Standardizing without explanation
* Calibrating data for QCA and using calibrated scores for NCA without justification

**Book references:** [Section 8.5.2](https://jandul.github.io/nca-book/#transformation), [Appendix D](https://jandul.github.io/nca-book/#appendixd)

\---

## Section: Methods — Data Analysis

### Item 20 — Must-have

**Question:** Is the selected ceiling line specified and justified?

**Recommendation (primary evaluative standard):** Specify and justify the selected ceiling line by considering: (1) theoretical expectations (border linear or non-linear), (2) type of data (discrete or continuous), (3) observed border pattern (regular or irregular), (4) balance between accuracy and generalizability (avoiding overfitting), and (5) quality of the data (with/without measurement error, simulated data).

**Pass criteria (Yes verdict requires ALL of):**

* The ceiling line is explicitly named (e.g., CE-FDH, CR-FDH, C-LP, CE-VRS)
* The justification connects the choice to at least one of: theoretical expectations, data type, observed pattern, accuracy/generalizability trade-off, data quality
* The justification is substantive, not generic ("we used the default" without rationale is insufficient)

**Fail conditions (No verdict if ANY of):**

* The ceiling line is not specified
* The choice is justified only by generic appeal ("we followed convention")
* A clearly inappropriate ceiling line is used (e.g., linear ceiling on a clearly non-linear border)

**Unclear verdict when:**

* The ceiling line is named but the justification is minimal
* Justification is implied through reference to a prior study but not explicitly argued

**Key concepts from the book:**

* CE-FDH (stepwise piecewise linear): default for non-linear borders and discrete data; 100% ceiling accuracy but higher complexity; overfitting risk
* CR-FDH (linear): default for continuous data with assumed linear border; allows noise above ceiling, useful when measurement error exists
* C-LP (linear, no points above): useful when data quality is high or ceiling should be deterministic
* CE-VRS (concave piecewise linear): for concave non-linear borders
* Justification must connect ceiling line choice to data characteristics and theoretical expectations
* Common justifications: CE-FDH for discrete Likert scales; CR-FDH for continuous data with linear border

**Common violations:**

* Selecting CR-FDH for non-linear data
* Citing only the software default without rationale
* Not distinguishing between ceiling line choices for different conditions when they differ in nature

**Book references:** [Section 4.3.2](https://jandul.github.io/nca-book/#mathceiling), [Section 9.3.2](https://jandul.github.io/nca-book/#ceilinglinespecification)

\---

### Item 21 — Should-have

**Question:** Is the bounding box (with empirical or theoretical scope) deliberately selected and specified?

**Recommendation (primary evaluative standard):** Specify and justify the selected bounding box (with empirical or theoretical scope). Commonly, the empirical scope is selected to avoid over-estimation of the effect size. The theoretical scope can be considered when X and Y are measured on bounded scales (e.g., Likert scales, percentages).

**Pass criteria (Yes verdict requires ALL of):**

* The scope is explicitly identified as empirical or theoretical
* A justification is provided (e.g., "empirical scope to avoid overestimation" or "theoretical scope because Likert scales have known bounds")
* The scope is consistent across all analyses unless variation is explained

**Fail conditions (No verdict if ANY of):**

* Scope is not stated
* Scope choice is not justified
* Scope is theoretical but the bounds are not specified

**Unclear verdict when:**

* The scope can be inferred from context (e.g., CE-FDH defaults to empirical) but is not stated
* The scope is stated for some analyses but not others

**Key concepts from the book:**

* Empirical scope: observed min/max; avoids overestimation; most common
* Theoretical scope: known bounds (e.g., Likert 1–7, percentage 0–100); appropriate when scale bounds are known and theoretically meaningful
* In longitudinal/group-comparison designs, pooled min/max may be used as theoretical scope for each group

**Common violations:**

* Empirical scope used without statement
* Theoretical scope claimed but bounds not specified
* Inconsistent scope across multiple analyses

**Book references:** [Section 4.3](https://jandul.github.io/nca-book/#formalexpression), [Section 9.3.1](https://jandul.github.io/nca-book/#scopespecification)

\---

### Item 22 — Should-have

**Question:** Are the hypothesis evaluation criteria (thresholds for effect size, p-value, and possibly target outcome) deliberately specified and justified?

**Recommendation (primary evaluative standard):** Specify and justify the selected threshold values for necessity effect size d and p-value for identifying necessity-in-kind. This threshold depends on the specific context of the study. If no argument is available for a specific value, common benchmark values may be used (d = 0.10; p = 0.05 with 10,000 permutations). Optionally, select a target outcome Y to evaluate necessity-in-degree.

**Pass criteria (Yes verdict requires ALL of):**

* The effect size threshold (d) is explicitly stated
* The p-value threshold (α) is explicitly stated
* The number of permutations is stated (default 10,000)
* The thresholds are justified, either by context-specific argument or by reference to standard benchmarks
* Thresholds are stated before the analysis, not post-hoc

**Fail conditions (No verdict if ANY of):**

* d threshold not stated
* p-value threshold not stated
* Number of permutations not stated
* Thresholds changed after seeing results

**Unclear verdict when:**

* Thresholds are stated but justification is minimal
* A target outcome for bottleneck analysis is implied but not stated

**Key concepts from the book:**

* Effect size thresholds: d=0.10 (small, "constrains 10% of outcome space"), d=0.30 (medium), d=0.50 (large)
* Selection should ideally be based on practical relevance
* p-value: α=0.05 standard; α=0.10 for exploration; α=0.005 for new discovery claims
* 10,000 permutations recommended for accuracy
* Target outcome for bottleneck: optional (e.g., 90th percentile of Y)

**Common violations:**

* Using "p < 0.05" stars without committing to a specific threshold
* Citing thresholds from a different field without contextual justification
* Stating thresholds in the results section only

**Book references:** [Section 4.4.1](https://jandul.github.io/nca-book/#effectsize), [Section 5.3](https://jandul.github.io/nca-book/#permutationtest), [Section 9.4.1](https://jandul.github.io/nca-book/#effectsizethreshold), [Section 9.4.2](https://jandul.github.io/nca-book/#pvaluethreshold)

\---

### Item 23 — Should-have

**Question:** Are the results of a visual inspection of the XY-plot reported?

**Recommendation (primary evaluative standard):** Conduct the analysis with the selected ceiling line and scope to obtain an XY-plot for visual inspection. Evaluate whether the expected corner is empty, if the selected ceiling line is appropriate, if potential outliers are present, and what the data pattern in the rest of the plot is.

**Pass criteria (Yes verdict requires ALL of):**

* The paper reports observations from visual inspection: whether the expected corner is empty
* The fit of the ceiling line to the border is discussed
* The general data pattern in the feasible area is briefly characterized

**Fail conditions (No verdict if ANY of):**

* No visual inspection is reported despite XY-plots being shown
* Only the empty corner is mentioned; ceiling line fit is unaddressed

**Unclear verdict when:**

* Visual observations are scattered across the results without being collected
* Some plots are inspected verbally but others are not

**Key concepts from the book:**

* Visual inspection precedes formal conclusions (Step 3 of data analysis workflow)
* Key checks: empty corner, ceiling line fit, potential outliers, data pattern in feasible area
* Sparse data in the upper-right region reduces the constraint's practical relevance

**Common violations:**

* Reporting only effect sizes and p-values without visual commentary
* Treating the XY-plot as a presentation device rather than an analytic step

**Book references:** [Section 9.5](https://jandul.github.io/nca-book/#visualinspection)

\---

### Item 24 — Must-have

**Question:** Is it explained how potential outliers are analyzed and handled, and are removed cases reported?

**Recommendation (primary evaluative standard):** Conduct an outlier analysis with the selected ceiling line and scope to identify potential ceiling and scope outliers. If outliers are removed, report in detail which cases are removed and why, and compare the results with and without removing the outliers (see robustness checks).

**Pass criteria (Yes verdict requires ALL of):**

* An outlier analysis is conducted (ceiling outliers and scope outliers)
* If outliers are removed, the specific cases removed are reported
* The reason for removal is reported (sampling error, measurement error, exception under typicality, mechanistic rule with justification)
* A brief note compares results with and without outlier removal (full robustness check is Item 36)
* If no outliers were identified or removed, this is stated

**Fail conditions (No verdict if ANY of):**

* No outlier analysis is reported
* Outliers are removed without specifying which cases or why
* The comparison of results with/without outliers is omitted

**Unclear verdict when:**

* Some outlier discussion is present but the procedure is not fully documented
* It is unclear whether outliers were absent or simply not analyzed

**Key concepts from the book:**

* Two outlier types: ceiling outliers (determine the ceiling line position) and scope outliers (determine the bounding box extent)
* Outlier decision process (Figure 9.3):

  1. Sampling/selection error → remove
  2. Measurement error correctable → correct; uncorrectable → remove (Y) or judge (X)
  3. Unknown reasons: mechanistic rules discouraged; if used, require theoretical justification
* Step 2 (Figure 9.4): typicality perspective for rare, isolated, unexplained exceptions; requires robustness check
* Item 24's requirement to "compare with/without outliers" is satisfied by a brief note (full robustness check belongs to Item 36)
* Original effect sizes (pre-removal) must always be reported

**Common violations:**

* Removing outliers without reporting which cases
* Applying a "20% rule" mechanically without theoretical justification
* Omitting the with/without comparison entirely

**Book references:** [Section 9.8](https://jandul.github.io/nca-book/#outliers), [Figures 9.3, 9.4](https://jandul.github.io/nca-book/#outlierdecisionmaking)

\---

### Item 25 — Should-have

**Question:** Are all model fit parameters evaluated?

**Recommendation (primary evaluative standard):** Conduct the analysis with the selected ceiling line and scope and evaluate the model fit parameters (complexity, fit, ceiling accuracy, noise, exceptions, support, spread, sharpness), and compare with benchmark values.

**Pass criteria (Yes verdict requires ALL of):**

* The eight model fit parameters are reported (complexity, fit, ceiling accuracy, noise, exceptions, support, spread, sharpness)
* Each is compared to its benchmark or interpreted
* Poor fit triggers reconsideration of the ceiling line choice

**Fail conditions (No verdict if ANY of):**

* Fewer than all eight parameters are reported
* Parameters are reported but not interpreted
* Effect size and p-value are the only metrics reported

**Unclear verdict when:**

* A subset of parameters is reported with interpretation; others are missing without explanation
* The parameters are in a supplementary table but not discussed

**Key concepts from the book:**

* Eight model fit parameters and benchmarks:

  * Complexity: linear lines cp=1; piecewise higher (overfitting risk)
  * Fit: % closeness to CE-FDH benchmark; <80% suggests poor border fit
  * Ceiling accuracy: % on or below ceiling; <95% suggests too many violations
  * Noise: % just above ceiling in medium-purity zone; should be <5%
  * Exceptions: points far above ceiling (low-purity zone); should be 0 for deterministic necessity
  * Support: % near ceiling in feasible area; should be >\~5%
  * Spread: dispersion near ceiling; >0.5 adequate
  * Sharpness: abruptness of transition; >0.8 for sharp separation
* All parameters produced by NCA software with summaries=TRUE

**Common violations:**

* Reporting only effect size and p-value
* Citing parameters without comparing to benchmarks
* Ignoring poor fit metrics rather than reconsidering ceiling line

**Book references:** [Section 4.5](https://jandul.github.io/nca-book/#modelfit), [Section 9.9](https://jandul.github.io/nca-book/#modelfit2), [Sections 9.9.1–9.9.9](https://jandul.github.io/nca-book/#complexity2)

\---

### Item 26 — Should-have

**Question:** Are all NCA-related parameters, terms and concepts properly used and described?

**Recommendation (primary evaluative standard):** Describe NCA-related parameters, terms, and concepts properly. This includes using "permutation test" (not bootstrapping, Monte Carlo simulation, robustness check, or t-test) for NCA's statistical test, and "multiple NCA" (not "multivariate NCA") for analyses with several necessity hypotheses.

**Pass criteria (Yes verdict requires ALL of):**

* "Permutation test" is used for NCA's statistical test
* "Multiple NCA" (not "multivariate NCA") is used for analyses with several hypotheses
* Standard NCA terminology is applied consistently throughout

**Fail conditions (No verdict if ANY of):**

* "Bootstrapping," "Monte Carlo," "robustness check," or "t-test" used for NCA's statistical test
* "Multivariate NCA" used for multiple-condition analyses
* NCA-specific terms (ceiling line, ceiling zone, scope, bottleneck) misused

**Unclear verdict when:**

* Some terminology is correct but isolated misuses appear
* Standard terminology is used but obscure terms appear that may or may not be NCA-specific

**Key concepts from the book:**

* Permutation test ≠ bootstrapping (no resampling with replacement)
* Permutation test ≠ Monte Carlo (deterministic given the data)
* Permutation test ≠ robustness check (it is the significance test)
* "Multivariate NCA" is incorrect: NCA is always bivariate (one X, one Y per analysis); multiple conditions = "multiple NCA"

**Common violations:**

* Calling the permutation test "bootstrapping"
* Using "multivariate NCA" for multi-condition studies
* Calling NCA a "robustness check" for another method

**Book references:** [Appendix A (Glossary)](https://jandul.github.io/nca-book/#glossary)

\---

### Item 27 — Nice-to-have

**Question:** Is the utilized software, including its version number specified?

**Recommendation (primary evaluative standard):** Specify which software and which version of the software was used to conduct NCA. The version number for the NCA package in R can be obtained with the command packageVersion("NCA").

**Pass criteria (Yes verdict requires ALL of):**

* Software name is specified (e.g., R package NCA)
* Version number is specified

**Fail conditions (No verdict if ANY of):**

* Software is named but version is not given
* Software is not specified at all

**Unclear verdict when:**

* A version range is given but not a specific version

**Key concepts from the book:**

* Specifying software and version ensures reproducibility
* Main NCA software is the R package NCA (CRAN)
* Different versions may produce different results or support different features

**Common violations:**

* Citing only "NCA package in R" without version
* Citing the foundational paper without specifying the software actually used

**Book references:** [Appendix B (Software)](https://jandul.github.io/nca-book/#appendixb)

\---

### Item 28 — Nice-to-have

**Question:** Is a short general description of NCA's data analysis approach provided to serve readers who are less familiar with NCA?

**Recommendation (primary evaluative standard):** Include a brief description of NCA's main logic and data analysis elements (ceiling line, ceiling zone, scope, effect size) so that the study is easier to understand for readers unfamiliar with NCA. Consider adding references for further reading.

**Pass criteria (Yes verdict requires ALL of):**

* A brief description of NCA's main logic appears
* Key elements are explained: ceiling line, ceiling zone, scope, effect size
* References for further reading are provided

**Fail conditions (No verdict if ANY of):**

* No description of NCA is provided
* Description omits one or more key elements
* The description assumes prior NCA knowledge without explanation

**Unclear verdict when:**

* Description is present but minimal
* References are provided but the description itself is missing

**Key concepts from the book:**

* Key elements to explain: ceiling line (border separating empty corner), ceiling zone (empty area), scope (bounding box), effect size d (proportion of scope occupied by ceiling zone, 0–1)
* Suggested references for further reading: Dul (2024b), Dul (2025)

**Common violations:**

* Citing NCA without explaining its logic
* Explaining the effect size formula without naming the four key elements

**Book references:** [Chapter 1](https://jandul.github.io/nca-book/#introduction), [Chapter 4](https://jandul.github.io/nca-book/#mathematics)

\---

## Section: Results

### Item 29 — Must-have

**Question:** Are XY-tables or XY-plots of all tested/explored relationships shown?

**Recommendation (primary evaluative standard):** Include the XY-tables or XY-plots of all tested/explored relationships, preferably in the main text. It is essential that readers are able to inspect them visually.

**Pass criteria (Yes verdict requires ALL of):**

* XY-tables or XY-plots are shown for all tested relationships, including non-significant ones
* The plots are in the main text (preferred) or clearly referenced supplementary material
* The plots are legible and properly labeled

**Fail conditions (No verdict if ANY of):**

* Only significant relationships are visualized
* Plots are too small or unlabeled to inspect

**Unclear verdict when:**

* Some plots are shown but others are omitted
* Plots are present but their quality limits inspection

**Key concepts from the book:**

* Visual inspection is a fundamental NCA step (Step 3)
* Readers must be able to verify the empty corner, assess ceiling line fit, identify outliers
* Main text preferred; supplementary acceptable for many relationships
* Multi-panel compact figures are appropriate for many relationships

**Common violations:**

* Showing only the strongest necessity relationships
* Hiding non-significant plots in supplementary
* Plots without axis labels or scales

**Book references:** [Section 9.5](https://jandul.github.io/nca-book/#visualinspection)

\---

### Item 30 — Should-have

**Question:** Is only the ceiling line that is used to draw conclusions about the necessity relationship shown in the XY-plot?

**Recommendation (primary evaluative standard):** In the XY-plots, include only the ceiling line used to draw conclusions about the necessity relationship. Note: the default NCA software output in R includes two ceiling lines (CE-FDH and CR-FDH), but only one should be selected for drawing conclusions. XY-plots with other ceiling lines explored before final selection, or evaluated during robustness checks, may be provided separately.

**Pass criteria (Yes verdict requires ALL of):**

* Each primary XY-plot shows only one ceiling line — the one used for conclusions
* If multiple ceiling lines are shown (e.g., for robustness checks), they are clearly separated from the primary results

**Fail conditions (No verdict if ANY of):**

* Default dual-ceiling output is presented as the primary result
* Multiple ceiling lines in the same primary plot without distinction

**Unclear verdict when:**

* Some plots show one line, others show two
* The distinction between primary and exploratory plots is unclear

**Key concepts from the book:**

* Default NCA software output shows both CE-FDH and CR-FDH
* Including both in primary results confuses which conclusions stem from which ceiling
* The selected ceiling line should match the one used for the reported effect size and p-value

**Common violations:**

* Using default software plots without removing the secondary line
* Showing two lines but reporting effect size for only one without clarification

**Book references:** [Section 9.3.2](https://jandul.github.io/nca-book/#ceilinglinespecification)

\---

### Item 31 — Must-have

**Question:** For large-n quantitative study: are the effect size and its p-value properly reported?

**Recommendation (primary evaluative standard):** Report the estimated effect size and its p-value. Preferably, report the effect size in two decimal places. Report the estimated p-value, preferably with three decimal places. Give exact p-values (or if applicable p < 0.001) and do not use inequalities or stars (i.e., not p < 0.05 or \*).

**Pass criteria (Yes verdict requires ALL of):**

* Effect sizes are reported to two decimal places
* p-values are reported as exact values (three decimal places preferred)
* The only acceptable inequality is "p < 0.001"
* Stars (\*, \*\*, \*\*\*) and inequalities like "p < 0.05" are NOT used

**Fail conditions (No verdict if ANY of):**

* p-values reported with stars
* p-values reported as inequalities other than "p < 0.001"
* Effect sizes rounded to one decimal place or fewer

**Unclear verdict when:**

* Reporting format cannot be clearly assessed from the available text (e.g., tables are not reproduced in full)

**Key concepts from the book:**

* Reporting stars or inequalities is explicitly prohibited
* Exact p-values enable readers to evaluate against alternative thresholds (e.g., α=0.01 or 0.005)
* Two decimal places for effect sizes balances precision and avoids false accuracy

**Common violations:**

* Tables with effect sizes followed by asterisks
* "p < 0.05" instead of exact value
* Inconsistent decimal places across tables

**Book references:** [Section 9.4](https://jandul.github.io/nca-book/#selectionevaluationcriteria)

\---

### Item 32 — Must-have

**Question:** Is the conclusion about necessity-in-kind based on three criteria: theoretical justification, effect size, and p-value?

**Recommendation (primary evaluative standard):** Conclude about necessity-in-kind using three criteria: (1) Theoretical justification (the formal hypothesis), (2) Effect size not below the selected threshold value, (3) p-value below the selected threshold value. All three criteria must be satisfied for non-rejection. Missing just one is enough for rejection. This implies that without theoretical justification, the claim for a necessity relationship is rejected regardless of effect size and p-value.

**Pass criteria (Yes verdict requires ALL of):**

* Items 7, 8, 9, and 10 are all satisfied — without these, the theoretical justification criterion fails by default and this item cannot receive Yes
* The conclusion explicitly invokes all three criteria: (1) formal theoretical hypothesis, (2) effect size at or above the pre-specified threshold, (3) p-value below the pre-specified threshold
* If any one criterion fails, the condition is rejected — regardless of strength on the others

**Fail conditions (No verdict if ANY of):**

* Items 7–10 are not satisfied, meaning no formal necessity hypothesis exists
* Conclusion is based only on effect size and p-value, with theoretical justification absent or implicit
* A condition is "accepted" despite a failure of one criterion

**Unclear verdict when:**

* The three criteria are listed in methods but the conclusion is stated only in terms of statistical thresholds
* Theoretical justification is partial (some elements present, others missing)

**Key concepts from the book:**

* All three criteria are required for non-rejection
* Missing one criterion → rejection
* Without a formal necessity hypothesis (with four elements and three-question causal explanation), the first criterion fails by default
* Large significant effects with no formal hypothesis → rejected
* Theoretically grounded large effects with non-significant p → rejected
* Theoretically grounded significant effects with below-threshold d → rejected

**Common violations:**

* Concluding necessity from statistical criteria alone
* Treating "theoretical justification" as "the variable was mentioned in prior literature"
* Inferring necessity from large effect sizes when p-value fails

**Book references:** [Section 9.10](https://jandul.github.io/nca-book/#necessityinkind)

\---

### Item 33 — Should-have

**Question:** Is the bottleneck table reported and necessity-in-degree evaluated?

**Recommendation (primary evaluative standard):** Report the bottleneck table ONLY for necessary conditions that were NOT rejected. This facilitates the evaluation of necessity-in-degree: which level of X is necessary for which level of Y.

**Pass criteria (Yes verdict requires ALL of):**

* A bottleneck table is reported
* The table includes ONLY conditions that were not rejected (passed all three criteria of Item 32)
* The bottleneck values are interpreted in terms of necessity-in-degree

**Fail conditions (No verdict if ANY of):**

* The bottleneck table includes rejected conditions
* No bottleneck table is reported despite non-rejected conditions existing
* The table is reported but not interpreted

**Unclear verdict when:**

* The table includes a condition whose rejection status is borderline (e.g., p just above threshold)
* The table is partial (some non-rejected conditions included, others omitted without explanation)

**Key concepts from the book:**

* Including rejected conditions in the bottleneck table is incorrect: a rejected condition has no established necessity, so its "necessary level" is meaningless
* Section 9.11.3: "Conditions that are not necessary (e.g., because theoretical support is missing, the effect size is too small, or the p-value is too large), should not be included in the table"
* The bottleneck table is only valid and interpretable for non-rejected conditions

**Common violations:**

* Showing bottleneck values for all tested conditions including those rejected by effect size
* Including conditions with marginal effects (e.g., d = 0.07) in the bottleneck table because they are "near-necessary"
* Including conditions without theoretical justification

**Book references:** [Section 9.11](https://jandul.github.io/nca-book/#bottleneck), [Section 9.11.3](https://jandul.github.io/nca-book/#multiple-necessary-conditions)

\---

### Item 34 — Nice-to-have

**Question:** If applicable: is the meaning of NN and NA in the bottleneck table explained?

**Recommendation (primary evaluative standard):** Explain the meaning of NN or NA in the bottleneck table if it appears.

**Pass criteria (Yes verdict requires ALL of):**

* If NN or NA appears in the table, its meaning is explained (in a note or in the text)
* The explanation distinguishes NN (not necessary at that level) from NA (computation not applicable)

**Fail conditions (No verdict if ANY of):**

* NN or NA appears without explanation
* The explanation conflates NN and NA

**Unclear verdict when:**

* Both NN and NA appear but only one is explained and it is unclear whether the other was intentionally omitted

**Key concepts from the book:**

* NN (Not Necessary): X is not necessary at the given level of Y; any X is compatible with that Y
* NA (Not Applicable): impossible to compute a required X value
* NA occurs when:

  1. The ceiling line intersects the right bound of the bounding box (resolvable with cutoff=1)
  2. In multi-condition tables, the case determining y\_max has a missing value for one condition

**Common violations:**

* Citing only NN without explaining NA
* Treating NN as "weak necessity" rather than "no necessity at this level"

**Book references:** [Section 9.11.5](https://jandul.github.io/nca-book/#na)

\---

### Item 35 — Should-have

**Question:** Are the type of values used in the bottleneck analysis justified?

**Recommendation (primary evaluative standard):** Justify the type of values for X and Y displayed in the bottleneck table (e.g., percentage of range, actual values, percentiles). In particular, actual values of Y and percentile values of X might be informative about the percentage or number of cases unable to achieve a target outcome.

**Pass criteria (Yes verdict requires ALL of):**

* The type of values (actual, percentile, percentage of range, percentage of maximum) is stated
* The choice is justified
* The justification connects the value type to the interpretive purpose

**Fail conditions (No verdict if ANY of):**

* The value type is not stated
* The value type is stated but not justified
* The chosen value type makes the table uninterpretable for the stated purpose

**Unclear verdict when:**

* The value type is inferable from the table but neither stated nor justified in the text

**Key concepts from the book:**

* Actual values: original scale scores; most interpretable when scales have practical meaning (e.g., Likert)
* Percentile values: reveal "what percentage of cases cannot achieve the required X"
* Useful combination: actual values for Y, percentile values for X — shows targeted Y level and actionable case proportion
* Percentage of range / maximum: less commonly used

**Common violations:**

* Using actual values without justifying why they are interpretable
* Using percentiles without explaining their case-proportion meaning
* Inconsistent value types across multiple tables

**Book references:** [Section 9.11.1](https://jandul.github.io/nca-book/#actual), [Section 9.11.2](https://jandul.github.io/nca-book/#percentile)

\---

### Item 36 — Must-have

**Question:** Are the results of the robustness checks summarized?

**Recommendation (primary evaluative standard):** Conduct robustness checks and summarize the results: is the main conclusion about necessity sensitive to choices by the analyst regarding ceiling line, scope, effect size threshold, p-value threshold, removing/keeping outliers, different choices for the target outcome? Conclude if the results are robust or fragile.

**Pass criteria (Yes verdict requires ALL of):**

* Robustness checks across the relevant analyst choices are conducted: ceiling line, scope, effect size threshold, p-value threshold, outliers, target outcome
* Not all six checks are required if some are not relevant (e.g., scope check trivial when bounded scale used); but the selection is justified
* Results are summarized in a robustness table (Table 9.1 format preferred) or equivalent structured presentation
* A conclusion is drawn: results are "robust" or "fragile"
* The outlier robustness check is a full sensitivity analysis (include/exclude alternatives, additional outliers), distinct from Item 24's brief comparison

**Fail conditions (No verdict if ANY of):**

* No robustness checks are reported
* Only one check is reported when multiple are relevant
* No conclusion about robustness/fragility is stated
* The outlier robustness check is omitted when outliers were removed

**Unclear verdict when:**

* Some robustness checks are conducted but not all relevant ones
* Results are reported but the robustness/fragility conclusion is missing

**Key concepts from the book:**

* Six robustness check types: ceiling line (9.12.1), scope (9.12.2), effect size threshold (9.12.3), p-value threshold (9.12.4), outliers (9.12.5), target outcome (9.12.6)
* Robustness table (Table 9.1): original result in row 1, alternatives in subsequent rows, columns for effect size, p-value, necessity conclusion, bottleneck percentages
* Not all checks always relevant — analyst selects applicable ones
* Outlier robustness in Item 36 is a full sensitivity analysis, NOT the brief comparison of Item 24
* Brief reporting of original effect sizes does NOT substitute for the full robustness analysis

**Common violations:**

* No robustness checks at all
* Reporting only original effect sizes before outlier removal and calling that a robustness check
* Conducting checks but not synthesizing a robust/fragile conclusion

**Book references:** [Section 9.12](https://jandul.github.io/nca-book/#robustnesschecks), [Sections 9.12.1–9.12.7](https://jandul.github.io/nca-book/#different-ceiling-line-choice), [Table 9.1](https://jandul.github.io/nca-book/#robustnesstable)

\---

## Section: Discussion

### Item 37 — Must-have

**Question:** Is it explained why all tested necessary conditions were (not) rejected?

**Recommendation (primary evaluative standard):** Summarize the results of using NCA in terms of which necessary conditions were tested/explored, and which were rejected or not rejected. Assuming methodological errors are unlikely, provide theoretical explanations for the results, referring to the necessity theory and hypotheses formulated earlier.

**Pass criteria (Yes verdict requires ALL of):**

* The discussion summarizes which conditions were tested
* For each non-rejected condition, a theoretical explanation linking back to the formal hypothesis and causal mechanism (enabler, constraint, non-compensability) is provided
* For each rejected condition, a theoretical explanation is offered (e.g., the condition is contributing but compensable; the theoretical domain too broad; alternative mechanism)
* Rejected results are treated as scientifically informative, not minimized

**Fail conditions (No verdict if ANY of):**

* Rejected conditions are ignored or only briefly noted
* Non-rejected conditions are discussed only in terms of effect size, not theoretical mechanism
* The discussion does not link results back to the hypothesis structure of Items 7–10

**Unclear verdict when:**

* Some conditions are discussed theoretically but others are mentioned only statistically
* The theoretical explanation is brief and does not clearly tie to the causal mechanism

**Key concepts from the book:**

* The discussion closes the loop between necessity theory and empirical result
* For non-rejected: link back to enabler/constraint/non-compensability narrative
* For rejected: explain why necessity does not hold (compensable contribution, domain mismatch, measurement, mis-specification)
* A rejected result is scientifically valid and informative

**Common violations:**

* Discussing only the strongest effects
* Treating rejections as "limitations" rather than results
* Not linking discussion back to the hypothesis development

**Book references:** [Section 7.5.3](https://jandul.github.io/nca-book/#causalexplanation)

\---

### Item 38 — Must-have

**Question:** For a multimethod study: is it explained how the results of NCA and of other methods complement each other?

**Recommendation (primary evaluative standard):** When NCA is used in a causal-pluralism study by combining it with another method (e.g., regression-based methods or QCA), report how the results of NCA and the other method complement each other using NERT, NEST and BIPMA when applicable.

**Pass criteria (Yes verdict requires ALL of):**

* The complementary insights from each method are explicitly described
* The relevant tool (NERT for NCA+regression, BIPMA for NCA+SEM, NEST for NCA+QCA) is used when applicable
* The discussion distinguishes what each method contributes (necessity, sufficiency, configurations)

**Fail conditions (No verdict if ANY of):**

* NCA results are merely reported alongside other method results without integration
* The methods are presented as alternatives rather than complementary
* Relevant integration tools are not used when applicable

**Unclear verdict when:**

* Integration is attempted but not via the recommended tools
* Complementarity is implied but not clearly articulated

**Key concepts from the book:**

* NERT (NCA-Extended Regression Table): for NCA+regression; shows necessity and average effects side by side
* BIPMA (Bottleneck Importance Performance Map Analysis): for NCA+SEM; combines importance-performance with bottleneck
* NEST (NCA-Extended Solution Table): for NCA+QCA; shows configurations that also satisfy necessary conditions
* Complementarity: NCA identifies bottlenecks (essential); regression/SEM identifies contributors (average); QCA identifies sufficient configurations

**Common violations:**

* Reporting both methods without integration
* Treating mismatches as inconsistencies rather than complementary perspectives
* Using NCA only as a robustness check

**N/A condition:** Standalone NCA studies.

**Book references:** [Chapter 11](https://jandul.github.io/nca-book/#multimethodstudies), [Sections 11.3–11.5](https://jandul.github.io/nca-book/#ncawithregressionbasedmethods)

\---

### Item 39 — Must-have

**Question:** Referring to the goals of the study (see introduction): is it discussed if the intended contribution is realized and what the key insights are?

**Recommendation (primary evaluative standard):** For the primary and possibly secondary goals (see introduction), discuss if the intended contribution is realized and what key insights are gained.

**Pass criteria (Yes verdict requires ALL of):**

* The discussion explicitly revisits the goals stated in the introduction
* For each goal: an assessment of whether the contribution was realized
* Key insights are stated concretely (not just "we contribute to the literature")

**Fail conditions (No verdict if ANY of):**

* The discussion does not return to the introduction's goals
* Contributions are claimed but not connected to specific findings
* Key insights are vague or generic

**Unclear verdict when:**

* Some goals are revisited; others are not
* Contributions are listed but their realization is not assessed

**Key concepts from the book:**

* Conversation structure (Section 10.2.1): common ground → complication → concern → course of action → contribution
* The discussion should answer: how has the academic conversation advanced?
* For practical goals: what actionable insights do managers or policymakers gain?

**Common violations:**

* Generic "our findings contribute to..." without specifics
* Failing to address whether the stated complications were resolved
* Listing implications without connecting them to specific results

**Book references:** [Section 10.2.1](https://jandul.github.io/nca-book/#empiricalpublication), [Tables 10.1, 10.2](https://jandul.github.io/nca-book/#review)

\---

### Item 40 — Should-have

**Question:** Are the results of the bottleneck analysis explained in terms of necessity-in-degree?

**Recommendation (primary evaluative standard):** If necessity-in-kind is accepted, provide an interpretation of necessity-in-degree using the results of the bottleneck analysis. For example, explain what level of X is necessary for a given target level of Y.

**Pass criteria (Yes verdict requires ALL of):**

* The discussion interprets the bottleneck table in substantive terms
* Specific threshold levels are translated into substantive meaning (e.g., "to achieve high Y, X must be at least Z, which corresponds to ...")
* Interpretation is restricted to non-rejected conditions (consistent with Item 33)
* Practical and theoretical implications of the thresholds are discussed

**Fail conditions (No verdict if ANY of):**

* The bottleneck table is reported but not discussed in the text
* Interpretation includes rejected conditions
* Thresholds are listed without substantive meaning

**Unclear verdict when:**

* Some thresholds are discussed but others ignored
* Interpretation is brief and does not clearly tie to actionable insight

**Key concepts from the book:**

* Necessity-in-degree provides actionable threshold information
* Only valid for non-rejected conditions (consistent with Item 33)
* Interpretation should be substantive, not numerical
* Critical: discussing necessity-in-degree for rejected conditions is scientifically invalid

**Common violations:**

* Discussing bottleneck for all conditions including rejected ones
* Listing thresholds without interpretation
* Failing to address practical implications

**Book references:** [Section 9.11](https://jandul.github.io/nca-book/#bottleneck)

\---

### Item 41 — Should-have

**Question:** Are limitations of applying NCA mentioned?

**Recommendation (primary evaluative standard):** Mention the study's limitations. Discuss general limitations of NCA (e.g., exclusive focus on necessity; potential sensitivity to outliers), and specific limitations of applying NCA in the current study, and how this may affect the findings.

**Pass criteria (Yes verdict requires ALL of):**

* General NCA limitations are mentioned (e.g., bivariate nature, focus on necessity only, outlier sensitivity)
* Study-specific limitations are mentioned (e.g., sample, design, measurement)
* Limitations are connected to how they may affect the findings — not just listed generically

**Fail conditions (No verdict if ANY of):**

* No limitations section is present
* No NCA-specific limitations are mentioned at all (general NCA limitations such as bivariate nature, outlier sensitivity, or focus on necessity are completely absent)

**Unclear verdict when:**

* General NCA limitations are discussed but study-specific ones are missing, or vice versa
* Limitations are mentioned but the connection to findings is implicit

**Key concepts from the book:**

* General NCA limitations: bivariate (no multivariate control), focus on necessity (not sufficiency/average), outlier sensitivity, observational designs cannot exclude reverse causality
* Study-specific limitations may include: convenience sampling, non-probability sample, single-informant data, common method bias, time period, country-level confounds

**Common violations:**

* Generic limitations not specific to NCA
* Mentioning limitations without addressing their impact
* Listing limitations as boilerplate

**Book references:** [Chapter 9](https://jandul.github.io/nca-book/#dataanalysis), [Chapter 5](https://jandul.github.io/nca-book/#statistics)

\---

### Item 42 — Should-have

**Question:** Are potential future studies with NCA discussed?

**Recommendation (primary evaluative standard):** Discuss potential future studies with NCA, for example conducting studies in other parts of the theoretical domain to assess the generalizability of the current findings, or applying NCA in related substantive areas that could benefit from the necessity causal perspective.

**Pass criteria (Yes verdict requires ALL of):**

* Future research directions specifically involving NCA are discussed
* Suggestions include replication in other parts of the theoretical domain OR application to related substantive areas
* Suggestions are concrete, not just "more research is needed"

**Fail conditions (No verdict if ANY of):**

* No future research directions are discussed
* Suggestions are generic ("more research") without NCA-specific content

**Unclear verdict when:**

* Some NCA-specific suggestions appear but others would be expected and are missing
* Future directions are discussed in generic terms but include NCA in passing

**Key concepts from the book:**

* Replication in other parts of the theoretical domain is critical for NCA (necessity claims apply to all cases in the domain; single study tests only a subset)
* Possible directions: replication, longitudinal designs, multimethod combination, related necessity hypotheses, alternative thresholds
* Reference: Köhler \& Cortina (2023) on constructive replication

**Common violations:**

* "More research is needed" boilerplate
* Generic future directions without NCA specificity
* No discussion of replication

**Book references:** [Chapter 7](https://jandul.github.io/nca-book/#hypothesisformulation), [Section 10.2](https://jandul.github.io/nca-book/#typesofncapublications)

